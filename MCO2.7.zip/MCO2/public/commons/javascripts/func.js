//A JQuery example on handling Ajax. It sends a request similar
//to a post but it does not load a file. Instead, it sends info
//back and a call-back function will process what happened.
//Read more here: 
//https://www.w3schools.com/jquery/jquery_ajax_intro.asp




// TEST LOGIN (NEED MONGODB TO MAKE LOGIN EASIER)
$(document).ready(function(){
    $("#login123").click(function(){
      $.post(
        '/read-user',

        { username: $('#unames').val(),
          password: $('#passwords').val(),
          isLoggedIn: true  },

        function(data, status){
            if(status === 'success') {
                var username = $('#unames').val();
                // $('#header-user-name').text(username);
                console.log("success");
            }
        })
    })

    $("#logout123").click(function(){
      $.post(
        '/logout',

        {username : $("#header-user-names").val()},

        function(data, status){
            if(status === 'success') {
                
                // $('#header-user-name').text(username);
                console.log("success");
            }
        })
    })
    
});//doc
  