const express = require('express')
const server = express()

const handlebars = require('express-handlebars')
const bodyParser = require('body-parser')
const path = require('path')

const helpers = require('./components/hbsHelpers.js')
const hbs = require('hbs')

const logRouter = require('./routes/log.js')
const profileRouter = require('./routes/profile.js')
const communityRouter = require('./routes/community.js')
const postRouter = require('./routes/post.js')

const dataModule = {
    data_communities: require('./getCommunites.js'),
    data_posts: require('./getPosts.js'),
    data_users: require('./getUsers.js')
};


hbs.registerPartials(path.join(__dirname, 'views/partials'), (err) => {})
for (let h in helpers){hbs.registerHelper(h, helpers[h])}

server.use(express.json())
server.use(express.urlencoded({ extended: true }))
server.set('view engine', 'hbs')
server.engine('hbs', handlebars.engine({
    extname: 'hbs'
}))

server.use(express.static('public'))

const mongoose = require('mongoose');
mongoose.connect('mongodb://127.0.0.1:27017/server');

function errorFn(err){
    console.log('Error fond. Please trace!');
    console.error(err);
}

const userSchema = new mongoose.Schema({
    uid:        {type: String},
    username:   {type: String},
    name:       {type: String},
    bio:        {type: String},
    pfp:        {type: String},
    posts:      {type: Number},
    logged_on:  {type: Boolean},
    password:   {type: String}
},{ versionKey: false });
  
const userModel = mongoose.model('user', userSchema);

const postSchema = new mongoose.Schema({
    pid:         {type: String},
    uid:         {type: String},
    cid:         [{type: String}],
    title:       {type: String},
    text:        {type: String},
    ifwithImage: {type: Boolean},
    image:       {type: String},
    date:        {type: String},
    up:          {type: Number},
    down:        {type: Number},
},{ versionKey: false });

const postModel = mongoose.model('post', postSchema);

const communitySchema = new mongoose.Schema({
    cid:            {type: String},
    community_name: {type: String},
    color:          {type: String},
    image:          {type: String},
    url:            {type: String}
},{ versionKey: false });

const communityModel = mongoose.model('community', communitySchema);

const commentSchema = new mongoose.Schema({
    pid:            {type: String},
    comment: [{
          uid:      {type: String},
          text:     {type: String},
          up:       {type: Number},
          down:     {type: Number},
          reply: [{
            uid:    {type: String},
            text:   {type: String},
            up:     {type: Number},
            down:   {type: Number}
          }]
    }]

}, {versionKey: false })

const commentModel = mongoose.model('comment', commentSchema);

const currentUser = []


server.get('/', function(req, resp){


    const searchQuery = {};

   
    userModel.find(searchQuery).lean().then(function(user_data)
    {
    postModel.find(searchQuery).lean().then(function(post_data)
    {
    communityModel.find(searchQuery).lean().then(function(community_data){
        const loggedInUsers = user_data.filter(user => user.logged_on === true);
        
        if(loggedInUsers.length === 0) {
            loggedInUsers.push({username: "User", logged_on: false})
        }

        const completePost = post_data.map(post => 
        {
        const user = user_data.find(user => user.uid === post.uid);
        const communities = post.cid.map(cid => community_data.find(community => community.cid === cid));
        return {
            ...post,
            user,
            communities
        }


        })

      

        
        // console.log(loggedInUsers.length)
        // console.log(loggedInUsers)
        
        resp.render('main', {
            layout: 'index',
            title:  'InfoSec',
            posts: completePost,
            community: community_data,
            user: loggedInUsers
        })
        

    }).catch(errorFn);
    }).catch(errorFn);
    }).catch(errorFn);

});

server.post('/read-user', function(req, resp){
    const searchQuery = { username: req.body.username, password: req.body.password };
  
    //The model can be found via a search query and the information is found
    //in the login function. Access the information like a JSon array.
    userModel.findOne(searchQuery).then(function(login){
      console.log('Finding user');
        console.log(searchQuery);
      if(login != undefined && login._id != null){
    
        login.logged_on = true;
        login.save();
        console.log("found");
        currentUser.push(searchQuery)
        console.log(currentUser)
      }else{
     
        console.log("none");
      }
    }).catch(errorFn);
  });

  server.post('/logout', function(req, resp){
    // console.log(String(req.body.username));

    userModel.updateOne.lean().then(function(user_data){

    const loggedInUsers = user_data.filter(user => user.logged_on === true);
    console.log(loggedInUsers);
    console.log(loggedInUsers.logged_on);


    }).catch(errorFn);







    // userModel.find().then(function(login)
    // {
    //     const logged= login.filter(user => user.logged_on === true);
    //     // loggedInUsers.logged_on = false;
    //     // loggedInUsers
    //     console.log(logged);

    //     // loggedInUsers.pop()
    //     // // console.log(loggedInUsers);
    //     // // console.log(loggedInUsers.length);
    //     // // // loggedInUsers.push({username: "User", logged_on: false})
    //     // if(loggedInUsers.length === 0) {
    //     //     loggedInUsers.push({username: "User", logged_on: false})
    //     // }
   
 
    //  }).catch(errorFn);
  });













 // remove once done testing

// server.get('/', (req, res) =>{ //index
//     const getCommunities = dataModule.data_communities.getCommunities()
//     const getPosts = dataModule.data_posts.getPosts()
//     const getUsers = dataModule.data_users.getUsers()

//     const completePost = getPosts.map(post => {
//         const user = getUsers.find(user => user.uid === post.uid);
//         const communities = post.cid.map(cid => getCommunities.find(community => community.cid === cid));
//         return {
//             ...post,
//             user,
//             communities
//         };
//     });

//     res.render('main', {
//         layout: 'index',
//         title:  'InfoSec',
//         posts: completePost,
//         community: getCommunities,
//         username: uname // remove once done testing
//     })
//     console.log(uname);
// })


server.use('/log', logRouter)
server.use('/profile', profileRouter)
server.use('/community', communityRouter)
server.use('/post', postRouter)

const port = process.env.PORT | 9090
server.listen(port, function(){
    console.log('Listening to port ' + port)
})