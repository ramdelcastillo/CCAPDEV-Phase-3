function getComments(){
	const fs = require('fs');
	let rawdata = fs.readFileSync('./data/comment.json');
	return JSON.parse(rawdata);
}

module.exports.getComments = getComments;