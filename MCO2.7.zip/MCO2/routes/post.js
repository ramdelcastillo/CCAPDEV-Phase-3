const express = require('express')
const router = express.Router()

const dataModule = {
    data_communities: require('../getCommunites.js'),
    data_posts: require('../getPosts.js'),
    data_users: require('../getUsers.js'),
    data_comments: require('../getComments.js')
};

const getCommunities = dataModule.data_communities.getCommunities()
const getPosts = dataModule.data_posts.getPosts()
const getUsers = dataModule.data_users.getUsers()
const getComments = dataModule.data_comments.getComments()


router.get('/:pid', (req, res) =>{
    const pid = req.params.pid
    const post = getPosts.find(post => post.pid === pid);

    if (!post) {res.render('../views/error', {
        layout: 'invalid',
        title: 'Not Found'
    })}

    const user = getUsers.find(user => user.uid === post.uid);
    const communities = post.cid.map(cid => getCommunities.find(community => community.cid === cid));
    const commentThread = getComments.filter(comment => comment.pid === pid)

    const mappedCT = commentThread.map(post => {
        const comments = post.comment.map(comment => {
            const user = getUsers.find(user => user.uid === comment.uid);
            const replies = comment.reply.map(reply => {
                const user = getUsers.find(user => user.uid === reply.uid);
                return { ...reply, user };
            });
            return { ...comment, user, reply: replies };
        });
        return { ...post, comment: comments };
    });

    res.render('../views/post', {
        layout: 'user',
        title: 'InfoSec',
        community: communities,
        user: user,
        post: post,
        commentThread: mappedCT
    })
})

module.exports = router