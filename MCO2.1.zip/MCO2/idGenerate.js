//https://youtu.be/lfmg-EJ8gm4

function generateID(len, lc, uc, num, sym){

    const lcchars = "abcdefghijklmnopqrstuvwxyz";
    const ucchars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    const nums = "0123456789";
    const symbols = "!@#$%^&*()_+-=><";

    let allowed = "";
    let id = "";

    allowed += lc ? lcchars : "";
    allowed += uc ? ucchars : "";
    allowed += num ? nums : "";
    allowed += sym ? symbols : "";

    for(let i = 0; i < len; i++){
        const randIndex = Math.floor(Math.random() * allowed.length);
        id += allowed[randIndex];
    }

    return id;
}

const idLen = 15;
const idlc = true;
const iduc = true;
const idnum = true;
const idsym = false;

const id = generateID(idLen, idlc, iduc, idnum, idsym);
console.log(`Generated ID: ${id}`);