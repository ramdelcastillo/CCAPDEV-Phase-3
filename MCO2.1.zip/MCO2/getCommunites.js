function getCommunities(){
	const fs = require('fs');
	let rawdata = fs.readFileSync('./data/community.json');
	return JSON.parse(rawdata);
}

module.exports.getCommunities = getCommunities;