const express = require('express')
const server = express()

const handlebars = require('express-handlebars')
const bodyParser = require('body-parser')
const path = require('path')

const helpers = require('./components/hbsHelpers.js')
const hbs = require('hbs')

const logRouter = require('./routes/log.js')
const profileRouter = require('./routes/profile.js')
const communityRouter = require('./routes/community.js')
const postRouter = require('./routes/post.js')

const dataModule = {
    data_communities: require('./getCommunites.js'),
    data_posts: require('./getPosts.js'),
    data_users: require('./getUsers.js')
};


hbs.registerPartials(path.join(__dirname, 'views/partials'), (err) => {})
for (let h in helpers){hbs.registerHelper(h, helpers[h])}

server.use(express.json())
server.use(express.urlencoded({ extended: true }))
server.set('view engine', 'hbs')
server.engine('hbs', handlebars.engine({
    extname: 'hbs'
}))

server.use(express.static('public'))

server.get('/', (req, res) =>{
    const getCommunities = dataModule.data_communities.getCommunities()
    const getPosts = dataModule.data_posts.getPosts()
    const getUsers = dataModule.data_users.getUsers()
    res.render('main', {
        layout: 'index',
        title:  'InfoSec',
        community: getCommunities,
        posts: getPosts,
        user: getUsers
    })
})

server.use('/log', logRouter)
server.use('/profile', profileRouter)
server.use('/community', communityRouter)
server.use('/post', postRouter)

const port = process.env.PORT | 9090
server.listen(port, function(){
    console.log('Listening to port ' + port)
})