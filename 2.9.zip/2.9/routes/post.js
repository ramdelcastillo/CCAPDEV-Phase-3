const express = require('express')
const router = express.Router()

// const dataModule = {
//     data_communities: require('../getCommunites.js'),
//     data_posts: require('../getPosts.js'),
//     data_users: require('../getUsers.js'),
//     data_comments: require('../getComments.js')
// };

// const getCommunities = dataModule.data_communities.getCommunities()
// const getPosts = dataModule.data_posts.getPosts()
// const getUsers = dataModule.data_users.getUsers()
// const getComments = dataModule.data_comments.getComments()

const mongoose = require('mongoose');
 mongoose.connect('mongodb://127.0.0.1:27017/server');


 
 function errorFn(err){
     console.log('Error fond. Please trace!');
     console.error(err);
 }

const userModel = require('../users.js');

const postModel = require('../posts.js');

const communityModel = require('../community.js');

const commentModel = require('../comments.js');



router.get('/:pid', (req, res) =>{
    const searchQuery = {};
    
    userModel.find(searchQuery).lean().then(function(user_data)
    {
    postModel.find(searchQuery).lean().then(function(post_data)
    {
    communityModel.find(searchQuery).lean().then(function(community_data)
    {
    commentModel.find(searchQuery).lean().then(function(commment_data)
    {

    
    const loggedInUsers = user_data.filter(user => user.logged_on === true);

    if(loggedInUsers.length === 0) {
        loggedInUsers.push({username: "User", logged_on: false})
    }


    const pid = req.params.pid
    const post = post_data.find(post => post.pid === pid);

    if (!post) {res.render('../views/error', {
        layout: 'invalid',
        title: 'Not Found'
    })}

    const user = user_data.find(user => user.uid === post.uid);
    const communities = post.cid.map(cid => community_data.find(community => community.cid === cid));
    const commentThread = commment_data.filter(comment => comment.pid === pid)

    const mappedCT = commentThread.map(post => {
        const comments = post.comment.map(comment => {
            const user = user_data.find(user => user.uid === comment.uid);
            const replies = comment.reply.map(reply => {
                const user = user_data.find(user => user.uid === reply.uid);
                return { ...reply, user };
            });
            return { ...comment, user, reply: replies };
        });
        return { ...post, comment: comments };
    });

    res.render('../views/post', {
        layout: 'user',
        title: 'InfoSec',
        community: communities,
        user: user,
        post: post,
        commentThread: mappedCT,
        log: loggedInUsers
    })

    }).catch(errorFn);
    }).catch(errorFn);
    }).catch(errorFn);
    }).catch(errorFn);
    
})

module.exports = router