const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
    uid:        {type: String},
    username:   {type: String},
    name:       {type: String},
    bio:        {type: String},
    pfp:        {type: String},
    posts:      {type: Number},
    logged_on:  {type: Boolean},
    password:   {type: String}
},{ versionKey: false });
  
module.exports = mongoose.model('user', userSchema);