function getPosts(){
	const fs = require('fs');
	let rawdata = fs.readFileSync('./data/post.json');
	return JSON.parse(rawdata);
}

module.exports.getPosts = getPosts;