function getUsers(){
	const fs = require('fs');
	let rawdata = fs.readFileSync('./data/user.json');
	return JSON.parse(rawdata);
}

module.exports.getUsers = getUsers;