const express = require('express')
const server = express()

const handlebars = require('express-handlebars')
const bodyParser = require('body-parser')
const path = require('path')

const helpers = require('./components/hbsHelpers.js')
const hbs = require('hbs')

const logRouter = require('./routes/log.js')
const profileRouter = require('./routes/profile.js')
const communityRouter = require('./routes/community.js')
const postRouter = require('./routes/post.js')

const dataModule = {
    data_communities: require('./getCommunites.js'),
    data_posts: require('./getPosts.js'),
    data_users: require('./getUsers.js')
};


hbs.registerPartials(path.join(__dirname, 'views/partials'), (err) => {})
for (let h in helpers){hbs.registerHelper(h, helpers[h])}

server.use(express.json())
server.use(express.urlencoded({ extended: true }))
server.set('view engine', 'hbs')
server.engine('hbs', handlebars.engine({
    extname: 'hbs'
}))

server.use(express.static('public'))

const mongoose = require('mongoose');
mongoose.connect('mongodb://127.0.0.1:27017/info');

function errorFn(err){
    console.log('Error fond. Please trace!');
    console.error(err);
}

const postSchema = new mongoose.Schema({
    pid: { type: String },
    uid: { type: String },
    cid: [{ type: String }],
    title: { type: String },
    text: { type: String },
    ifwithImage: { type: Boolean },
    image: { type: String },
    date: { type: String },
    up: { type: String }, 
    down: { type: String },
  }, { versionKey: false });
  
const postModel = mongoose.model('post', postSchema);

const communitySchema = new mongoose.Schema({
    cid: { type: String },
    community_name: { type: String },
    color: { type: String },
    image: { type: String },
    url: { type: String },
  }, { versionKey: false });
  
const communityModel = mongoose.model('community', communitySchema);

const userSchema = new mongoose.Schema({
    uid: { type: String },
    username: { type: String },
    name: { type: String },
    bio: { type: String },
    pfp: { type: String },
    posts: { type: String },
    logged_on: { type: Boolean },
  }, { versionKey: false });
  
  const userModel = mongoose.model('user', userSchema);

const uname = [] // remove once done testing

server.get('/', (req, res) => {
    const searchQuery = {};
  
    postModel.find(searchQuery).lean().then((post_data) => {
      communityModel.find(searchQuery).lean().then((community_data) => {
        userModel.find(searchQuery).lean().then((user_data) => {
        const getUsers = dataModule.data_users.getUsers();

        const getCommunities = dataModule.data_communities.getCommunities();
        const completePost = post_data.map((post) => {
          const user = getUsers.find((user) => user.uid === post.uid);
          const communities = post.cid.map((cid) => getCommunities.find((community) => community.cid === cid));
          return {
            ...post,
            user,
            communities,
          };
        });
  
        res.render('main', {
          layout: 'index',
          title: 'InfoSec',
          posts: post_data,
          community: community_data,
          username: uname, // remove once done testing
        });
            }).catch((error) => {
                console.error('Error retrieving users:', error);
                res.status(500).send('Internal Server Error');
            });
      }).catch((error) => {
        console.error('Error retrieving communities:', error);
        res.status(500).send('Internal Server Error');
      });
    }).catch((error) => {
      console.error('Error retrieving posts:', error);
      res.status(500).send('Internal Server Error');
    });
  });
  
  


// remove once done testing
server.post('/log/loggedin', function(req, resp){
    var username = String(req.body.username);
    var loggedIn = Boolean(req.body.isLoggedIn)

    var response = {
        user: username,
        isLoggedIn: loggedIn
    }

    resp.send(response);
    uname.push(response);
});




server.use('/log', logRouter)
server.use('/profile', profileRouter)
server.use('/community', communityRouter)
server.use('/post', postRouter)

const port = process.env.PORT | 9090
server.listen(port, function(){
    console.log('Listening to port ' + port)
})