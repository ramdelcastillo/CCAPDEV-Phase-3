const express = require('express')
const router = express.Router()

router.get('/signup', (req, res) => {
    res.render('../views/partials/signup', {
        layout: 'log',
        title: 'InfoSec'
    })
})

router.get('/login', (req, res) => {
    res.render('../views/partials/login', {
        layout: 'log',
        title: 'InfoSec'
    })
})

module.exports = router