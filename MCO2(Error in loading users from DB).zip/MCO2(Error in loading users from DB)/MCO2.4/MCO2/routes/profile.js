const express = require('express')
const router = express.Router()

const dataModule = {
    data_communities: require('../getCommunites.js'),
    data_posts: require('../getPosts.js'),
    data_users: require('../getUsers.js')
};

const getCommunities = dataModule.data_communities.getCommunities()
const getPosts = dataModule.data_posts.getPosts()
const getUsers = dataModule.data_users.getUsers()


router.get('/:uid', (req, res) =>{
    const uid = req.params.uid
    const selected_user = getUsers.find(user => user.uid === uid)

    if (!selected_user) {res.render('../views/error', {
        layout: 'invalid',
        title: 'Not Found'
    })}

    const userPosts = getPosts.filter(post => post.uid === uid)
    const completePost = userPosts.map(post => {
        const communities = post.cid.map(cid => {
            return getCommunities.find(community => community.cid === cid);
        });

        return {
            ...post,
            user: selected_user,
            communities: communities
        };
    });

    res.render('../views/profile', {
        layout: 'user',
        title: 'InfoSec',
        user: selected_user,
        posts: completePost
    })
})

module.exports = router