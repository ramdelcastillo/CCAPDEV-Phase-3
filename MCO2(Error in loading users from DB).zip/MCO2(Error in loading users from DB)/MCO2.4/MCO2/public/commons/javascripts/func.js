//A JQuery example on handling Ajax. It sends a request similar
//to a post but it does not load a file. Instead, it sends info
//back and a call-back function will process what happened.
//Read more here: 
//https://www.w3schools.com/jquery/jquery_ajax_intro.asp




// TEST LOGIN (NEED MONGODB TO MAKE LOGIN EASIER)
$(document).ready(function(){
    $("#login123").click(function(){
      $.post(
        '/log/loggedin',

        { username: $('#unames').val(),
          password: $('#passwords').val(),
          isLoggedIn: true  },

        function(data, status){
            if(status === 'success') {
                var username = $('#unames').val();
                // $('#header-user-name').text(username);
            }
        })
    })
    
});//doc
  