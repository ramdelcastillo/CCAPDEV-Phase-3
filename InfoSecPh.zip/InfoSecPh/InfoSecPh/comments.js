const mongoose = require('mongoose');

const commentSchema = new mongoose.Schema({
    pid:            {type: String},
    comment: [{
          uid:      {type: String},
          text:     {type: String},
          up:       {type: Number},
          down:     {type: Number},
          reply: [{
            uid:    {type: String},
            text:   {type: String},
            up:     {type: Number},
            down:   {type: Number}
          }]
    }]
}, {versionKey: false })

module.exports = mongoose.model('comment', commentSchema);
