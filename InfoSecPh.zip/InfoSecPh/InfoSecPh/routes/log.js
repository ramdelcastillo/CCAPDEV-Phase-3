const express = require('express')
const router = express.Router()


const mongoose = require('mongoose');
mongoose.connect('mongodb://127.0.0.1:27017/server');

function errorFn(err){
    console.log('Error fond. Please trace!');
    console.error(err);
}


const userModel = require('../users.js');

const postModel = require('../posts.js');

const communityModel = require('../community.js');

const commentModel = require('../comments.js');



router.get('/signup', (req, res) => {

    const searchQuery = {};

    userModel.find(searchQuery).lean().then(function(user_data) {
        postModel.find(searchQuery).lean().then(function(post_data) {
            communityModel.find(searchQuery).lean().then(function(community_data) {
              
                    
                  // console.log(top_posts);
                  const loggedInUsers = user_data.filter(user => user.logged_on === true);
          
                  if(loggedInUsers.length === 0) {
                      loggedInUsers.push({username: "User", logged_on: false})
                  }
          
                  const completePost = post_data.map(post => 
                  {
                  const user = user_data.find(user => user.uid === post.uid);
                  const communities = post.cid.map(cid => community_data.find(community => community.cid === cid));
                  
                  return {
                      ...post,
                      user,
                      communities
                  }
            
                  })
                  res.render('../views/partials/signup', {
                    layout: 'log',
                    title: 'InfoSec',
                    communityHeader: community_data,
                    log: loggedInUsers
                })
  
  
              
            }).catch(errorFn) 
        }).catch(errorFn) 
    }).catch(errorFn) 

})

router.get('/login', (req, res) => {

    const searchQuery = {};

    userModel.find(searchQuery).lean().then(function(user_data) {
        postModel.find(searchQuery).lean().then(function(post_data) {
            communityModel.find(searchQuery).lean().then(function(community_data) {
              
                    
                  // console.log(top_posts);
                  const loggedInUsers = user_data.filter(user => user.logged_on === true);
          
                  if(loggedInUsers.length === 0) {
                      loggedInUsers.push({username: "User", logged_on: false})
                  }
          
                  const completePost = post_data.map(post => 
                  {
                  const user = user_data.find(user => user.uid === post.uid);
                  const communities = post.cid.map(cid => community_data.find(community => community.cid === cid));
                  
                  return {
                      ...post,
                      user,
                      communities
                  }
            
                  })
                  res.render('../views/partials/login', {
                    layout: 'log',
                    title: 'InfoSec',
                    communityHeader: community_data,
                    log: loggedInUsers
                }) 
  
  
              
            }).catch(errorFn) 
        }).catch(errorFn) 
    }).catch(errorFn) 
})

module.exports = router