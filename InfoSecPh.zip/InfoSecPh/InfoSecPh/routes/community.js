const express = require('express')
const router = express.Router();

const mongoose = require('mongoose');
 mongoose.connect('mongodb://127.0.0.1:27017/server');


 function errorFn(err){
     console.log('Error fond. Please trace!');
     console.error(err);
 }

const userModel = require('../users.js');

const postModel = require('../posts.js');

const communityModel = require('../community.js');

const commentModel = require('../comments.js');
 

router.get('/:cid', (req, res) =>{


    // console.log(models);
    const searchQuery = {};
    
    userModel.find(searchQuery).lean().then(function(user_data)
    {
    postModel.find(searchQuery).lean().then(function(post_data)
    {
    communityModel.find(searchQuery).lean().then(function(community_data){
       
    
    const loggedInUsers = user_data.filter(user => user.logged_on === true);

    if(loggedInUsers.length === 0) {
        loggedInUsers.push({username: "User", logged_on: false})
    }

    const cid = req.params.cid
    const selected_community = community_data.find(community => community.cid === cid)

    if (!selected_community) {res.render('../views/error', {
        layout: 'invalid',
        title: 'Not Found'
    })}

    const communityPosts = post_data.filter(post => post.cid.includes(selected_community.cid));
    const completePost = communityPosts.map(post => {
        const user = user_data.find(user => user.uid === post.uid);
        const communities = post.cid.map(cid => community_data.find(community => community.cid === cid));
        return {
            ...post,
            user,
            communities
        };
    });


    postModel.aggregate([
        { $match: {cid: cid} },
        { 
            $addFields: {
                totalvote: { $add: [{"$toInt":"$up"}, {"$toInt":"$down"}] }
            }
        },
        { $sort: { totalvote: -1 } },
        { $limit: 3 }
      ]).then(function(top_posts){
    
    res.render('../views/main', {
        layout: 'index',
        title:  'InfoSec',
        posts: completePost,
        community: community_data,
        log: loggedInUsers,
        communityHeader: community_data,
        top_posts: top_posts
    })

    // console.log(selected_user);
    }).catch(errorFn);
    }).catch(errorFn);
    }).catch(errorFn);
    }).catch(errorFn);








  
})

module.exports = router