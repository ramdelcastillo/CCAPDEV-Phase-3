const express = require('express')
const router = express.Router()

 const mongoose = require('mongoose');
 mongoose.connect('mongodb://127.0.0.1:27017/server');


 
 function errorFn(err){
     console.log('Error fond. Please trace!');
     console.error(err);
 }

 const userModel = require('../model/users.js');

 const postModel = require('../model/posts.js');
 
 const communityModel = require('../model/community.js');
 
 const commentModel = require('../model/comments.js');
 


router.get('/:uid', (req, res) =>{
    // console.log(models);
    const searchQuery = {};
    
    userModel.find(searchQuery).lean().then(function(user_data)
    {
    postModel.find(searchQuery).lean().then(function(post_data)
    {
    communityModel.find(searchQuery).lean().then(function(community_data){
    
    const loggedInUsers = user_data.filter(user => user.logged_on === true);

    if(loggedInUsers.length === 0) {
        loggedInUsers.push({username: "User", logged_on: false})
    }


    const uid = req.params.uid
    const selected_user = user_data.find(user => user.uid === uid)

    if (!selected_user) {res.render('../views/error', {
        layout: 'invalid',
        title: 'Not Found'
    })}
    
    const userPosts = post_data.filter(post => post.uid === uid)
    const completePost = userPosts.map(post => {
        const communities = post.cid.map(cid => {
            return community_data.find(community => community.cid === cid);
        });

        return {
            ...post,
            user: selected_user,
            communities: communities
        };
    });


    res.render('../views/profile', {
        layout: 'user',
        title: 'InfoSec',
        user: selected_user,
        posts: completePost,
        log: loggedInUsers,
        community: community_data,
        communityHeader: community_data

    })

    // console.log(selected_user);

    }).catch(errorFn);
    }).catch(errorFn);
    }).catch(errorFn);
})






















// router.get('/:uid', (req, res) =>{
//     const uid = req.params.uid
//     const selected_user = getUsers.find(user => user.uid === uid)

//     if (!selected_user) {res.render('../views/error', {
//         layout: 'invalid',
//         title: 'Not Found'
//     })}

//     const userPosts = getPosts.filter(post => post.uid === uid)
//     const completePost = userPosts.map(post => {
//         const communities = post.cid.map(cid => {
//             return getCommunities.find(community => community.cid === cid);
//         });

//         return {
//             ...post,
//             user: selected_user,
//             communities: communities
//         };
//     });

//     res.render('../views/profile', {
//         layout: 'user',
//         title: 'InfoSec',
//         user: selected_user,
//         posts: completePost
//     })
// })

module.exports = router