$(document).ready(function() {
    $('#reply').click(function() {
        $('.create-reply').toggle();
    });
});