const express = require('express')
const router = express.Router()

const mongoose = require('mongoose');
mongoose.connect('mongodb://127.0.0.1:27017/server');

const userModel = require('../model/schema/users.js');
const postModel = require('../model/schema/posts.js');
const communityModel = require('../model/schema/community.js');

function errorFn(err) {
    console.error('Error:', err);
}

router.get('/:uid', async (req, res) => {
    try {
        const searchQuery = {};
        let leanUser;

        const user_data = await userModel.find(searchQuery).lean();
        const post_data = await postModel.find(searchQuery).populate('uid').populate('cid').lean();
        const community_data = await communityModel.find(searchQuery).lean();
        
        if (req.user) {leanUser = req.user.toObject();}
    
        const uid = req.params.uid;
        const selected_user = user_data.find(user => user._id.toString() === uid);
    
        if (!selected_user) {
            return res.render('../views/error', {
                layout: 'invalid',
                title: 'Not Found'
            });
        }

        const userPosts = post_data.filter(post => post.uid._id.toString() === uid);
    
        res.render('../views/profile', {
            layout: 'user',
            title: 'InfoSec',
            user: selected_user,
            posts: userPosts,
            log: leanUser,
            communityHeader: community_data,
        });
    
    } catch (err) {
        errorFn(err);
        res.status(500).send('Internal Server Error');
    }
});

module.exports = router