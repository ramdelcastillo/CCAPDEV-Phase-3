const express = require('express')
const router = express.Router();

const mongoose = require('mongoose');
mongoose.connect('mongodb://127.0.0.1:27017/server');

const userModel = require('../model/schema/users.js');
const postModel = require('../model/schema/posts.js');
const communityModel = require('../model/schema/community.js');

function errorFn(err) {
    console.error('Error:', err);
}

router.get('/:cid', async (req, res) => {
    try {
        const searchQuery = {};
        let leanUser;
        
        const post_data = await postModel.find(searchQuery).populate('uid').populate('cid').lean();
        const community_data = await communityModel.find(searchQuery).lean();
    
        if (req.user) {leanUser = req.user.toObject();}
    
        const cid = req.params.cid;
        const selected_community = community_data.find(community => community._id.toString() === cid);
    
        if (!selected_community) {
            return res.render('../views/error', {
                layout: 'invalid',
                title: 'Not Found'
            });
        }
        const communityPosts = post_data.filter(post => post.cid.some(obj => obj._id.toString() === cid));

        postModel.aggregate([{ $match: {cid: cid} },
            { 
                $addFields: {totalvote: { $add: [{"$toInt":"$up"}, {"$toInt":"$down"}] }}
            },
            { $sort: { totalvote: -1 } },
            { $limit: 3 }
        ]).then(function(top_posts){
    
            res.render('../views/main', {
                layout: 'index',
                title: 'InfoSec',
                posts: communityPosts,
                log: leanUser,
                communityHeader: community_data,
                top_posts: top_posts
            });
        }).catch(errorFn);
    
    } catch (err) {
        errorFn(err);
        res.status(500).send('Internal Server Error');
    }
});

module.exports = router