//Install Command:
//npm init
//npm i express express-handlebars body-parser mongoose hbs
//npm i bcrypt passport passport-local express-session express-flash dotenv method-override

if (process.env.NODE_ENV !== 'production'){
  require('dotenv').config()
}

const express = require('express')
const helper = require('./components/hbsHelpers.js');
const server = express()

const methodOverride = require('method-override')
const flash = require('express-flash')
const session = require('express-session')
const passport = require('passport')
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const handlebars = require('express-handlebars')
const bodyParser = require('body-parser')
const path = require('path')

const logRouter = require('./routes/log.js')
const profileRouter = require('./routes/profile.js')
const communityRouter = require('./routes/community.js')
const postRouter = require('./routes/post.js')

const userModel = require('./model/schema/users.js');
const postModel = require('./model/schema/posts.js');
const communityModel = require('./model/schema/community.js');

const initializePassport = require('./public/commons/javascripts/passport-config.js')
initializePassport(passport)


server.use(methodOverride('_method'))
server.use(express.json())
server.use(express.urlencoded({ extended: true }))
server.use(flash())
server.use(session({
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false
}))
server.use(passport.initialize())
server.use(passport.session())

const hbs = require('hbs')
server.set('view engine', 'hbs')
server.engine('hbs', handlebars.engine({
  extname: 'hbs',
  helpers: {
    if_cond: helper.if_cond,
    isInCollection: helper.isInCollection,
    isSameId: helper.isSameId
  }
}))

server.use(express.static('public'))

const mongoose = require('mongoose');
mongoose.connect('mongodb://127.0.0.1:27017/server');

function errorFn(err) {
  console.error('Error:', err);
}

function sortedDate(array, limit) {
  const sortedArray = array.sort((a, b) => new Date(b.date) - new Date(a.date));
  
  if (limit !== undefined) 
    return sortedArray.slice(0, limit);
  
  return sortedArray;
}

function getFormattedDate() {
  const currentDate = new Date();
  const options = {
      year: 'numeric', month: 'numeric', day: 'numeric',
      hour: 'numeric', minute: 'numeric', second: 'numeric',
      hour12: true
  };
  return currentDate.toLocaleString('en-US', options);
}


server.get('/', async (req, res) => {
  try {
    const searchQuery = {};
    let leanUser;

    const community_data = await communityModel.find(searchQuery).lean();
    const post_data = await postModel.find(searchQuery).populate('uid').populate('cid').lean();
    const top_posts = await postModel.aggregate([
      { $match: searchQuery },
      { $addFields: {totalvote: { $add: [{"$toInt":"$up"}, {"$toInt":"$down"}] }}},
      { $sort: { totalvote: -1 } },
      { $limit: 4 }
    ]);

    if (req.user) {leanUser = req.user.toObject();}

    const posts = sortedDate(post_data);

    res.render('main', {
      layout: 'index',
      title:  'InfoSec',
      posts: posts,
      log: leanUser,
      top_posts: top_posts,
      recent_posts: sortedDate(post_data, 3),
      communityHeader: community_data,
    });

  } catch (error) {
    console.error('Error retrieving data:', error);
    res.status(500).send('Internal Server Error');
  }
});

server.delete('/logout', (req, res, next) => {
  req.logOut((err) => {
    if (err) {
      return next(err);
    }
    res.redirect('/');
  });
});

server.use('/log', logRouter)
server.use('/profile', profileRouter)
server.use('/community', communityRouter)
server.use('/post', postRouter)

const port = process.env.PORT | 3000
server.listen(port, function(){
  console.log('Listening to port ' + port)
})