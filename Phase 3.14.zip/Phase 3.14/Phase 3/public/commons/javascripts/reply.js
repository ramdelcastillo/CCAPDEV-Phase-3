$(document).ready(function() {
    // Add event listener to the reply button
    $('#reply').click(function() {
        // Toggle the display of the create-reply div
        $('.create-reply').toggle();
    });



    
});