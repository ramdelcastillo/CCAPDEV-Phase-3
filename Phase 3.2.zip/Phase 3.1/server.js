//Install Command:
//npm init
//npm i express express-handlebars body-parser mongoose hbs

const express = require('express')
const server = express()

const handlebars = require('express-handlebars')
const bodyParser = require('body-parser')
const path = require('path')

const helpers = require('./components/hbsHelpers.js')
const hbs = require('hbs')

const logRouter = require('./routes/log.js')
const profileRouter = require('./routes/profile.js')
const communityRouter = require('./routes/community.js')
const postRouter = require('./routes/post.js')

hbs.registerPartials(path.join(__dirname, 'views/partials'), (err) => {})
for (let h in helpers){hbs.registerHelper(h, helpers[h])}

server.use(express.json())
server.use(express.urlencoded({ extended: true }))
server.set('view engine', 'hbs')
server.engine('hbs', handlebars.engine({
    extname: 'hbs'
}))

server.use(express.static('public'))

const mongoose = require('mongoose');
mongoose.connect('mongodb://127.0.0.1:27017/server');

function errorFn(err){
    console.log('Error fond. Please trace!');
    console.error(err);
}


const userModel = require('./model/users.js');

const postModel = require('./model/posts.js');

const communityModel = require('./model/community.js');

const commentModel = require('./model/comments.js');

function shuffleArray(array) {
  const randomSort = () => Math.random() - 0.5;
  return array.sort(randomSort);
}

server.get('/', function(req, resp){

    const searchQuery = {};

    userModel.find(searchQuery).lean().then(function(user_data) {
      postModel.find(searchQuery).lean().then(function(post_data) {
          communityModel.find(searchQuery).lean().then(function(community_data){
              postModel.aggregate([
                { $match: searchQuery },
                { 
                    $addFields: {
                        totalvote: { $add: [{"$toInt":"$up"}, {"$toInt":"$down"}] }
                    }
                },
                { $sort: { totalvote: -1 } },
                { $limit: 5 }
              ]).then(function(top_posts) {
                top_posts.forEach(function(post) {
                  const dateObject = new Date(post.date);
                  const dateString = dateObject.toLocaleString(); // Convert ISODate to string in local time zone
                  // console.log(dateString);
              });
                // console.log(top_posts);
                const loggedInUsers = user_data.filter(user => user.logged_on === true);
        
                if(loggedInUsers.length === 0) {
                  loggedInUsers.push({username: "User", logged_on: false})
                }
        
                const completePost = post_data.map(post =>{
                  const user = user_data.find(user => user.uid === post.uid);
                  const communities = post.cid.map(cid => community_data.find(community => community.cid === cid));
                
                  return {
                    ...post,
                    user,
                    communities
                  }
          
                })
                resp.render('main', {
                    layout: 'index',
                    title:  'InfoSec',
                    posts: completePost,
                    community: community_data,
                    log: loggedInUsers,
                    top_posts: top_posts,
                    communityHeader: community_data
                });   
              }).catch(function(error) {
                  console.error('Error retrieving top posts:', error);
                  resp.status(500).send('Internal Server Error');
              });
          }).catch(function(error) {
              console.error('Error retrieving communities:', error);
              resp.status(500).send('Internal Server Error');
          });
      }).catch(function(error) {
          console.error('Error retrieving posts:', error);
          resp.status(500).send('Internal Server Error');
      });
  }).catch(function(error) {
      console.error('Error retrieving users:', error);
      resp.status(500).send('Internal Server Error');
  });
});

server.get('/error', function(req, resp){
  resp.render('../views/error', {
    layout: 'invalid',
    title: 'InfoSec',
  }) 
});

server.post('/read-user', function(req, resp){
    const searchQuery = { username: req.body.username, password: req.body.password };
  
    userModel.findOne(searchQuery).then(function(login){
      // console.log('Finding user');
        // console.log(searchQuery);
      if(login != undefined && login._id != null){
    
        login.logged_on = true;
        login.save();
         console.log("found");
      }else{
     
         console.log("none");
      }
    }).catch(errorFn);
  });

  server.post('/logout', function(req, resp){
    const searchQuery = {logged_on: true};

    userModel.findOne(searchQuery).then(function(user_data)
    {
      user_data.logged_on = false;
      user_data.save();
      // console.log("logged off");
    }).catch(errorFn);

  });


server.use('/log', logRouter)
server.use('/profile', profileRouter)
server.use('/community', communityRouter)
server.use('/post', postRouter)

const port = process.env.PORT | 3000
server.listen(port, function(){
    console.log('Listening to port ' + port)
})

