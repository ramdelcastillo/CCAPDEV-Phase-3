const express = require('express')
const router = express.Router()


const mongoose = require('mongoose');
mongoose.connect('mongodb://127.0.0.1:27017/server');

function errorFn(err){
    console.log('Error fond. Please trace!');
    console.error(err);
}


const userModel = require('../model/users.js');

 const postModel = require('../model/posts.js');
 
 const communityModel = require('../model/community.js');
 
 const commentModel = require('../model/comments.js');



router.get('/signup', (req, res) => {

    const searchQuery = {};

    userModel.find(searchQuery).lean().then(function(user_data) {
        postModel.find(searchQuery).lean().then(function(post_data) {
            communityModel.find(searchQuery).lean().then(function(community_data) {
              
                    
                  // console.log(top_posts);
                  const loggedInUsers = user_data.filter(user => user.logged_on === true);
          
                  if(loggedInUsers.length === 0) {
                      loggedInUsers.push({username: "User", logged_on: false})
                  }
          
                  const completePost = post_data.map(post => 
                  {
                  const user = user_data.find(user => user.uid === post.uid);
                  const communities = post.cid.map(cid => community_data.find(community => community.cid === cid));
                  
                  return {
                      ...post,
                      user,
                      communities
                  }
            
                  })
                  res.render('../views/partials/signup', {
                    layout: 'log',
                    title: 'InfoSec',
                    communityHeader: community_data,
                    log: loggedInUsers
                })
  
  
              
            }).catch(errorFn) 
        }).catch(errorFn) 
    }).catch(errorFn) 

})

router.get('/login', (req, res) => {

    const searchQuery = {};

    userModel.find(searchQuery).lean().then(function(user_data) {
        postModel.find(searchQuery).lean().then(function(post_data) {
            communityModel.find(searchQuery).lean().then(function(community_data) {
              
                    
                  // console.log(top_posts);
                  const loggedInUsers = user_data.filter(user => user.logged_on === true);
          
                  if(loggedInUsers.length === 0) {
                      loggedInUsers.push({username: "User", logged_on: false})
                  }
          
                  const completePost = post_data.map(post => 
                  {
                  const user = user_data.find(user => user.uid === post.uid);
                  const communities = post.cid.map(cid => community_data.find(community => community.cid === cid));
                  
                  return {
                      ...post,
                      user,
                      communities
                  }
            
                  })
                  res.render('../views/partials/login', {
                    layout: 'log',
                    title: 'InfoSec',
                    communityHeader: community_data,
                    log: loggedInUsers
                }) 
  
  
              
            }).catch(errorFn) 
        }).catch(errorFn) 
    }).catch(errorFn) 
})

router.get('/about', (req, res) =>{

    const searchQuery = {};

    communityModel.find(searchQuery).lean().then(function(community_data) {
        res.render('../views/partials/about', {
            layout: 'nav',
            title: 'InfoSec',
            communityHeader: community_data,
        })
    }).catch(errorFn) 
})

router.get('/friends', (req, res) =>{

    const searchQuery = {};

    communityModel.find(searchQuery).lean().then(function(community_data) {
        userModel.find(searchQuery).lean().then(function(user_data){
            res.render('../views/partials/friends', {
                layout: 'user',
                title: 'InfoSec',
                user: user_data,
                communityHeader: community_data,
            })
        }).catch(errorFn)
    }).catch(errorFn) 
})

router.get('/settings', (req, res) =>{

    const searchQuery = {};

    communityModel.find(searchQuery).lean().then(function(community_data) {
        res.render('../views/partials/settings', {
            layout: 'nav',
            title: 'InfoSec',
            communityHeader: community_data,
        })
    }).catch(errorFn) 
})


module.exports = router