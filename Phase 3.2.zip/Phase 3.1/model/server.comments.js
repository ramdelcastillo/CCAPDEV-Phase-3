[
{
  "pid": "cv2WMdAS5YjBrh9",
  "comment": [
    {
      "uid": "EAVHPBHDElfB4so",
      "text": "To be or to not to be Spiderman 2099",
      "up": "212",
      "down": "15",
      "reply": [
        {
          "uid": "5js8sYXr8vrc3Wg",
          "text": "LETS GOOO!!!",
          "up": "25",
          "down": "2"
        },
        {
          "uid": "7dsr5cvIxZnklRW",
          "text": "Awesome!",
          "up": "55",
          "down": "6"
        },
        {
          "uid": "5js8sYXr8vrc3Wg",
          "text": "LETS GOOO!!!",
          "up": "25",
          "down": "2"
        },
        {
          "uid": "7dsr5cvIxZnklRW",
          "text": "Awesome!",
          "up": "55",
          "down": "6"
        }
      ]
    },
    {
      "uid": "5js8sYXr8vrc3Wg",
      "text": "Time to download Spiderman 2099",
      "up": "111",
      "down": "10",
      "reply": [
        {
          "uid": "HXYJnB412ASuDyw",
          "text": "XDD",
          "up": "12",
          "down": "1"
        }
      ]
    },
    {
      "uid": "5js8sYXr8vrc3Wg",
      "text": "Time to download Spiderman 2099",
      "up": "111",
      "down": "10",
      "reply": [
        {
          "uid": "HXYJnB412ASuDyw",
          "text": "XDD",
          "up": "12",
          "down": "1"
        }
      ]
    }
  ]
},

{
    "pid": "clTNulwfUz7jlIZ",
    "comment": [
      {
        "uid": "7dsr5cvIxZnklRW",
        "text": "Theory will only take you so far",
        "up": "0",
        "down": "999",
        "reply": [
          {
            "uid": "5js8sYXr8vrc3Wg",
            "text": "This is not helpful at all",
            "up": "25",
            "down": "1"
          },
          {
            "uid": "HXYJnB412ASuDyw",
            "text": "Bro thinks hes oppenheimer",
            "up": "35",
            "down": "0"
          }
        ]
      },
      {
        "uid": "tH1kGQJ86FNuwhY",
        "text": "Got no proof but its 85% programming and 15% theory",
        "up": "115",
        "down": "10",
        "reply": [
          {
            "uid": "tH1kGQJ86FNuwhY",
            "text": "Thank you very much!",
            "up": "12",
            "down": "0"
          }
        ]
      }
    ]
  },

  {
    "pid": "Sd0pPKXtTwdzduI",
    "comment": [
      {
        "uid": "EAVHPBHDElfB4so",
        "text": "Are you trolling???",
        "up": "12",
        "down": "10",
        "reply": []
      },
      {
        "uid": "7dsr5cvIxZnklRW",
        "text": "I AINT READING ALLAT!!!",
        "up": "99",
        "down": "5",
        "reply": [
          {
            "uid": "HXYJnB412ASuDyw",
            "text": "Please read it :<",
            "up": "5",
            "down": "12"
          }
        ]
      }
    ]
  },

  {
    "pid": "uy1wWxe8obqts99",
    "comment": [
      {
        "uid": "EAVHPBHDElfB4so",
        "text": "REAL!!!",
        "up": "512",
        "down": "15",
        "reply": [
          {
            "uid": "5js8sYXr8vrc3Wg",
            "text": "thats funny lol",
            "up": "33",
            "down": "1"
          },
          {
            "uid": "7dsr5cvIxZnklRW",
            "text": "glad you find it funny",
            "up": "55",
            "down": "6"
          }
        ]
      },
      {
        "uid": "EAVHPBHDElfB4so",
        "text": "What can you do, they really need to do something about it!",
        "up": "53",
        "down": "10",
        "reply": [
          {
            "uid": "7dsr5cvIxZnklRW",
            "text": "Do you have any ideas?",
            "up": "12",
            "down": "1"
          }
        ]
      },
      {
        "uid": "7dsr5cvIxZnklRW",
        "text": "Please check out my profile for more funny memes :D",
        "up": "1",
        "down": "10",
        "reply": []
      }
    ]
  },

  {
    "pid": "EvsBudY7nzRAK2T",
    "comment": [
      {
        "uid": "tH1kGQJ86FNuwhY",
        "text": "Guys I srsly need help!!!",
        "up": "212",
        "down": "15",
        "reply": [
          {
            "uid": "7dsr5cvIxZnklRW",
            "text": "Call the cyberpolice!",
            "up": "222",
            "down": "2"
          },
          {
            "uid": "tH1kGQJ86FNuwhY",
            "text": "How do I call them?",
            "up": "164",
            "down": "6"
          },
          {
            "uid": "EAVHPBHDElfB4so",
            "text": "He is trolling you",
            "up": "153",
            "down": "2"
          },
          {
            "uid": "7dsr5cvIxZnklRW",
            "text": "XDDDD",
            "up": "55",
            "down": "6"
          }
        ]
      },
      {
        "uid": "EAVHPBHDElfB4so",
        "text": "Best to ask stackoverflow bro",
        "up": "53",
        "down": "10",
        "reply": [
          {
            "uid": "tH1kGQJ86FNuwhY",
            "text": "I already did but they told me to check that forum from 9 years ago and then downvoted me",
            "up": "99",
            "down": "1"
          },
          {
            "uid": "EAVHPBHDElfB4so",
            "text": "Classic",
            "up": "32",
            "down": "1"
          }
        ]
      },
      {
        "uid": "7dsr5cvIxZnklRW",
        "text": "Its 2024 just ask chat GPT",
        "up": "11",
        "down": "10",
        "reply": [
          {
            "uid": "tH1kGQJ86FNuwhY",
            "text": "I'll make an account right now",
            "up": "12",
            "down": "1"
          }
        ]
      }
    ]
  }]