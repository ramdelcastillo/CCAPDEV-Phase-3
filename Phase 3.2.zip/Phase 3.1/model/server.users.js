[{
  "_id": {
    "$oid": "65ee92196c27250c75c0e617"
  },
  "uid": "EAVHPBHDElfB4so",
  "username": "g4n6",
  "name": "Gio Ascan",
  "bio": "We think outside the box, but we’re still inside the internet.",
  "pfp": "https://wallpapercave.com/wp/wp8218764.jpg",
  "posts": 5,
  "logged_on": false,
  "password": "123",
  "friends": [
    "EAVHPBHDElfB4so",
    "5js8sYXr8vrc3Wg",
    "HXYJnB412ASuDyw",
    "tH1kGQJ86FNuwhY"
  ],
  "bookmarks": [
    "cv2WMdAS5YjBrh9",
    "clTNulwfUz7jlIZ",
    "Sd0pPKXtTwdzduI",
  ]
},
{
  "_id": {
    "$oid": "65ee92196c27250c75c0e618"
  },
  "uid": "5js8sYXr8vrc3Wg",
  "username": "Pikasaur",
  "name": "Jerome Gutierrez",
  "bio": "I only played pokemon Ruby",
  "pfp": "https://img.artpal.com/95405/2-15-9-21-14-45-47m.jpg",
  "posts": 5,
  "logged_on": false,
  "password": "123",
  "friends": [
    "EAVHPBHDElfB4so",
    "tH1kGQJ86FNuwhY",
  ],
  "bookmarks": [
    "Sd0pPKXtTwdzduI"
  ]
},
{
  "_id": {
    "$oid": "65ee92196c27250c75c0e619"
  },
  "uid": "HXYJnB412ASuDyw",
  "username": "Naz",
  "name": "Keinaz Domingo ",
  "bio": "Too lazy for a bio",
  "pfp": "https://cdn.vectorstock.com/i/preview-1x/77/70/handyman-monkey-wrench-circle-cartoon-vector-9967770.jpg",
  "posts": 5,
  "logged_on": false,
  "password": "123",
  "friends": [
    "EAVHPBHDElfB4so",
    "tH1kGQJ86FNuwhY",
  ],
  "bookmarks": [
    "cv2WMdAS5YjBrh9",
    "clTNulwfUz7jlIZ",
    "Sd0pPKXtTwdzduI",
    "EvsBudY7nzRAK2T",
    "TJRRR7329zQBL9Y",
    "uOif7k7obe0tg2r"
  ]
},
{
  "_id": {
    "$oid": "65ee92196c27250c75c0e61a"
  },
  "uid": "tH1kGQJ86FNuwhY",
  "username": "drnelp",
  "name": "Marnel Peradilla ",
  "bio": "Why are oranges called oranges, but apples aren't called red?",
  "pfp": "https://pyxis.nymag.com/v1/imgs/d6a/dc7/4a5001b7beea096457f480c8808572428b-09-roll-safe.rsquare.w400.jpg",
  "posts": 5,
  "logged_on": false,
  "password": "123",
  "friends": [
    "HXYJnB412ASuDyw"
  ],
  "bookmarks": [
    "TJRRR7329zQBL9Y",
    "uOif7k7obe0tg2r"
  ]
},
{
  "_id": {
    "$oid": "65ee92196c27250c75c0e61b"
  },
  "uid": "7dsr5cvIxZnklRW",
  "username": "Cybersec Memes",
  "name": "Ryan Giran ",
  "bio": "I am unironically a mod. Pls DM me",
  "pfp": "https://f8n-production.s3.amazonaws.com/creators/profile/lg4xls4wg-pepeft-jpg-jxc37f.jpg",
  "posts": 5,
  "logged_on": false,
  "password": "123",
  "friends": [
    "EAVHPBHDElfB4so",
    "5js8sYXr8vrc3Wg",
    "HXYJnB412ASuDyw",
    "tH1kGQJ86FNuwhY"
  ],
  "bookmarks": [
    "clTNulwfUz7jlIZ",
    "Sd0pPKXtTwdzduI",
    "9B544SFLs69Fidv"
  ]
}]