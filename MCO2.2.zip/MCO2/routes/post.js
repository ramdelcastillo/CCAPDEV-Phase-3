const express = require('express')
const router = express.Router()

const dataModule = {
    data_communities: require('../getCommunites.js'),
    data_posts: require('../getPosts.js'),
    data_users: require('../getUsers.js')
};

const getCommunities = dataModule.data_communities.getCommunities()
const getPosts = dataModule.data_posts.getPosts()
const getUsers = dataModule.data_users.getUsers()


router.get('/:pid', (req, res) =>{
    const pid = req.params.pid
    const post = getPosts.find(post => post.pid === pid);

    if (!post) {res.render('../views/error', {
        layout: 'invalid',
        title: 'Not Found'
    })}

    res.render('../views/post', {
        layout: 'user',
        title: 'InfoSec',
        community: getCommunities,
        user: getUsers,
        post: post
    })
})

module.exports = router