const express = require('express')
const router = express.Router()

const dataModule = {
    data_communities: require('../getCommunites.js'),
    data_posts: require('../getPosts.js'),
    data_users: require('../getUsers.js')
};

const getCommunities = dataModule.data_communities.getCommunities()
const getPosts = dataModule.data_posts.getPosts()
const getUsers = dataModule.data_users.getUsers()


router.get('/:cid', (req, res) =>{
    const cid = req.params.cid
    const community = getCommunities.find(community => community.cid === cid)
    const communityPosts = getPosts.filter(post => post.tag.some(tag => tag.cid === cid))

    if (!community) {res.render('../views/error', {
        layout: 'invalid',
        title: 'Not Found'
    })}
    
    res.render('../views/main', {
        layout: 'index',
        title: 'InfoSec',
        community: getCommunities,
        user: getUsers,
        posts: communityPosts
    })
})

module.exports = router